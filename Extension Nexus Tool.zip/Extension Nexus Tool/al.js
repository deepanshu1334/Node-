$(".fa-caret-down").remove();
$(".dropdown").remove();