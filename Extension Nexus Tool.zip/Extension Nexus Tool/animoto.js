$(".logged-in-user-nav").html("");
$(".wh-flexUser").html("");
$('a[href="/pricing"]').remove();
$('body').mouseover(function() {
$(".logged-in-user-nav").html("");
$(".wh-flexUser").html("");
$('a[href="/pricing"]').remove();
 });