$(".nav-menu-user-avatar").remove();
$(".nav-menu-notifications").remove();