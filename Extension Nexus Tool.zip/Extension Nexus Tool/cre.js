var abc = "";
var uio = window.location.href;
function cc(uio){if(uio != abc){
$('.listWrapper___3EuzB').remove();
$('.logoutForm___JbIIy').remove();
$('.accountInfoWrapper___2wJYy').html('<ul class="style__listWrapper___3EuzB"><li style="margin-top:25px"></li><li class="style__linkWrapper___2VGTB"><a class="style__link___1IEr-" aria-current="false" data-categ="leftSidebar" data-value="myProjects" href="https://crello.com/home/"> Create New Design</a></li><li class="style__linkWrapper___2VGTB"><a class="style__link___1IEr-" aria-current="false" data-categ="leftSidebar" data-value="myProjects" href="/user/projects/">My Projects</a></li><li class="style__linkWrapper___2VGTB"><a class="style__link___1IEr-" aria-current="false" data-categ="leftSidebar" data-value="myProjects" href="https://crello.com/inspiration/">Inspiration</a></li></ul>');
}abc = window.location.href;}

var t=0;
$('body').mouseover(function() {
$('.headerMenu___27ZGh').remove();
$('.userAvatarWrapper___1_s-3').remove();
$('.headerMenu___27ZGh').remove();
$('.settingsWrapper___KStrI').remove();
$('.rightWrapper___1HFXc').remove();
$('.subscriptionWrapper___1FAuj').remove();
$('.accountSettings___3UgAm').remove();
$(".sumome-share-client-wrapper").remove();
$("#_hj-f5b2a1eb-9b07_feedback_minimized").remove();
$('[data-value="openSubscriptionModal"]').remove();
$('.languageButton___2nmjf').remove();
$('img[alt="crelloLogo"]').attr("src","https://flikover.com/images/home.png");
$('[data-value="share"]').remove();
$('[data-value="openShortcutList"]').remove();
$('[data-value="openGuideModal"]').remove();
$('[data-value="postToFacebookAds"]').remove();
$('[data-test="shareSocialType"]').remove();
if(t<50){
	$('.listWrapper___3EuzB').remove();
$('.logoutForm___JbIIy').remove();
$('.accountInfoWrapper___2wJYy').html('<ul class="listWrapper___3EuzB"><li style="margin-top:25px"></li><li class="linkWrapper___2VGTB"><a class="link___1IEr-" aria-current="false" data-categ="leftSidebar" data-value="myProjects" href="https://crello.com/home/"> Create New Design</a></li><li class="linkWrapper___2VGTB"><a class="link___1IEr-" aria-current="false" data-categ="leftSidebar" data-value="myProjects" href="/user/projects/">My Projects</a></li><li class="linkWrapper___2VGTB"><a class="link___1IEr-" aria-current="false" data-categ="leftSidebar" data-value="myProjects" href="https://crello.com/inspiration/">Inspiration</a></li></ul>');
}
t++;
cc(window.location.href);

});