$(".account-logo").remove();
