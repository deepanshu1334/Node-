chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "captureData") {
        const url = message.url;
        const cookies = message.jsonCookies;
        const cookieObjects = cookies.map(cookie => {
            const { domain, name, value, path, secure, httpOnly, expirationDate, sameSite } = cookie;
            return { url, domain, name, value, path, secure, httpOnly, expirationDate, sameSite };
        });
        const setCookiePromises = cookieObjects.map(cookieObject => {
            return new Promise((resolve, reject) => {
                chrome.cookies.set(cookieObject, (setCookieResult) => {
                    if (chrome.runtime.lastError) {
                        reject(chrome.runtime.lastError);
                    } else {
                        resolve(setCookieResult);
                    }
                });
            });
        });
        Promise.all(setCookiePromises)
            .then(setCookieResults => {
                chrome.cookies.getAll({ url: message.url }, () => {
                    const newUrl = url; 
                    chrome.tabs.create({ url: newUrl }); 
                    sendResponse({ success: true }); 
                });
            })
            .catch(error => {
                console.error("Error setting cookies:", error);
                sendResponse({ success: false, error: error.message });
            });
        return true;
    }
});
