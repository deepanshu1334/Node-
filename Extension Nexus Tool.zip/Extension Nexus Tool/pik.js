$('body').mouseover(function() {

$(".navbar-notification").remove();
$(".navbar-usersetting").remove();
$(".sskb-help").remove();
$(".dashboard-header").remove();
$(".dashboard-inspire").remove();
$(".tab-team-up-hover").remove();
$(".team-up-helper-card").remove();
$(".pricing-outer-box").remove();
$(".team-up").remove();

	});


