$(".account-menu-item").remove();
