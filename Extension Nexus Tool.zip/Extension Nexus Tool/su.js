$(".su-blue-button").remove();
$("#sui-user-menu").remove();