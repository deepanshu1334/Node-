$(".infor-bell").remove();
$(".user-infor").remove();
