$('body').mouseover(function() {

    $('[data-name="logout-lnk"]').remove();

});