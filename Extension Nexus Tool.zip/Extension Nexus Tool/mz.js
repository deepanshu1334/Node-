$(".mgn-profile-image-small").remove(); 
$(".mgn-item").remove();